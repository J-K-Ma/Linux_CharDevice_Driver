/home/apprentice/Intelligent_Security_system/drv/test/Basic_char/basic_char.ko
/home/apprentice/Intelligent_Security_system/drv/test/Basic_char/basic_char.o
